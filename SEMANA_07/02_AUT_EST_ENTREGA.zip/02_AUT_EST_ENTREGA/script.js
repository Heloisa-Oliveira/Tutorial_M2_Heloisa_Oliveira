async function pega_personalidade(){
    console.log("oi")

    const xml = new XMLHttpRequest();

    xml.open("GET", "http://127.0.0.1:3000/listapersonalidade", true); // abrir a requisição, definir o método e se é assíncrona
    xml.onreadystatechange = function(){  //receber respota do servidor
        if(xml.readyState == 4 && xml.status == 200){ // requisição bem feita = 200
            var resposta = JSON.parse(this.responseText);
            console.log(resposta)
            for(i = 0; i<resposta.length; i++){
                const personalidade = document.createElement("div");
                personalidade.innerHTML = resposta[i].nome;

                document.getElementById("lista_personalidade").appendChild(personalidade);
            }
        }
    }
}