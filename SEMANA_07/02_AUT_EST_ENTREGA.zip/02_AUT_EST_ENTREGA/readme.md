# Exercício para entrega na SEMANA 7 - referente ao conteúdo trabalhado na etapa 6 (`SEMANA06/02_TUTORIAL`)

## Descrição
Atualize seu projeto individual do currículo profissional adicionando uma requisição que envolva a aplicação de AJAX.

## Forma de entrega
- Publique a sua solução no seu Github pessoal (criado com o e-mail Inteli conforme instruído no tutorial da Semana 1)
- Na resposta ao card na Adalove, inclua o link para o seu Github